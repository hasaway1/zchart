package com.example.demo.controller;

import java.util.*;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
public class ChartController {
	@GetMapping("/data1")
	public ResponseEntity<Map<String,Object>> data1() {
		List months = Arrays.asList("1월", "2월", "3월", "4월", "5월", "6월");
		List values = Arrays.asList(1255, 1913, 374, 528, 215, 367);
		Map<String, Object> map = new HashMap<>();
		map.put("months", months);
		map.put("values", values);
		return ResponseEntity.ok(map);
	}
	
	// /data1과 동일한 데이터 응답
	@GetMapping("/data2")
	public ResponseEntity<Map<String,Object>> data2() {
		List months = Arrays.asList("1월", "2월", "3월", "4월", "5월", "6월");
		List values = Arrays.asList(1255, 1913, 374, 528, 215, 367);
		Map<String, Object> map = new HashMap<>();
		map.put("months", months);
		map.put("values", values);
		return ResponseEntity.ok(map);
	}
	
	@GetMapping("/data3")
	public ResponseEntity<Map<String,Object>> data3() {
		String title1 = "2020년 상반기 판매량";
		List months1 = Arrays.asList("1월", "2월", "3월", "4월", "5월", "6월");
		List values1 = Arrays.asList(1255, 1913, 374, 528, 215, 367);
		Map<String, Object> map1 = new HashMap<>();
		map1.put("title", title1);
		map1.put("months", months1);
		map1.put("values", values1);
		
		String title2 = "2021년 상반기 판매량";
		List months2 = Arrays.asList("1월", "2월", "3월", "4월", "5월", "6월");
		List values2 = Arrays.asList(1317, 1728, 874, 628, 335, 467);
		Map<String, Object> map2 = new HashMap<>();
		map2.put("title", title2);
		map2.put("months", months2);
		map2.put("values", values2);
		
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("lastYear", map1);
		resultMap.put("thisYear", map2);
		return ResponseEntity.ok(resultMap);
	}
	
	@GetMapping("/data4")
	public ResponseEntity<Map<String,Object>> data4() {
		List countries = Arrays.asList("이탈리아", "프랑스", "스페인", "미국", "아르헨티나");
		List values = Arrays.asList(55, 49, 44, 24, 15);
		Map<String, Object> map = new HashMap<>();
		map.put("countries", countries);
		map.put("values", values);
		return ResponseEntity.ok(map);
	}
	
	// /data4와 동일한 데이터 응답
	@GetMapping("/data5")
	public ResponseEntity<Map<String,Object>> data5() {
		List countries = Arrays.asList("이탈리아", "프랑스", "스페인", "미국", "아르헨티나");
		List values = Arrays.asList(55, 49, 44, 24, 15);
		Map<String, Object> map = new HashMap<>();
		map.put("countries", countries);
		map.put("values", values);
		return ResponseEntity.ok(map);
	}
}
